
</div><!--closing.container-->


<!-- Auto-complete plugin. be used on Users/Detail -> select the Organization -->
<!--
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>-->
<!--<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />-->

<script type="text/javascript" src="<?php echo base_url('ace_assets/fromremote/select2.min.js');?>"></script>
<link href="<?php echo base_url('ace_assets/fromremote/select2.min.css');?>" rel="stylesheet">



<!--
<link href="<?php echo base_url('ace_assets/css/select2.css');?>" rel="stylesheet">-->

<!-- bootstrap-->
<link href="<?php echo base_url('ace_assets/js/bootstrap.js');?>" rel="stylesheet">


<!--这三个暂时不能用-->

<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<!--
<script src="<?php echo base_url('ace_assets/fromremote/popper.min.js');?>" ></script>
<script src="<?php echo base_url('ace_assets/fromremote/bootstrap.min.js');?>" ></script>
-->
<!-- The popup confirm, be used on when active/inactive an user-->
<!--
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.0/jquery-confirm.min.css">
-->

<link href="<?php echo base_url('ace_assets/fromremote/jquery-confirm.min.css');?>" rel="stylesheet">


<script src="<?php echo base_url('ace_assets/js/jquery-confirm.js');?>"></script>

<!-- datepicker, right now used for user created date search-->
<script type="text/javascript" src="<?php echo base_url('ace_assets/js/bootstrap-datepicker.min.js');?>"></script>
<link href="<?php echo base_url('ace_assets/css/bootstrap-datepicker3.standalone.min.css');?>" rel="stylesheet">


<!-- =======================Javascript and styles built by myself======================= -->
<!-- auto validation when submit a form-->
<script type="text/javascript" src="<?php echo base_url('ace_assets/js/ajax_validation.js');?>"></script>
<script type="text/javascript" src="<?php echo base_url('ace_assets/js/non_ajax_validation.js');?>"></script>
<link href="<?php echo base_url('ace_assets/css/style.css');?>" rel="stylesheet">
<script type="text/javascript" src="<?php echo base_url('ace_assets/js/tools.js');?>"></script>

</body>
</html>
