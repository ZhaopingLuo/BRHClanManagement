
<div class="row page-heading bg-light">
<div class="col page-title"><h2><?php echo $title; ?></h2></div>
</div>
<div class="wizard_panel">
	<div class="modal-content">
		<div class="modal-body">
			<div class="progress" style="margin-bottom: 20px;">
				<div class="progress-bar progress-bar-striped bg-success" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">
					4/4
				</div>

			</div>

			<div class="alert alert-success" role="alert">
				<div class="card-body">
					<h5 class="card-title">Congratulations</h5>
					<p class="card-text">
						Your new password has been set.
					</p>
				</div>
			</div>

		</div>

	</div>
</div>

</div>
